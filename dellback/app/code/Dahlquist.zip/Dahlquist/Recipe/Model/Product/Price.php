<?php namespace Dahlquist\Recipe\Model\Product;
class Price extends \Magento\Catalog\Model\Product\Type\Price
{
}
